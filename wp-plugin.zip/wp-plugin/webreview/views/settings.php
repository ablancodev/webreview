<?php if (!defined('ABSPATH')) exit; $s = WebReview_Client::settings(); ?>
<div class="wrap webreview">
    <h1>WebReview · Ajustes</h1>
    <form method="post" action="options.php">
        <?php settings_fields('webreview_settings_group'); ?>
        <table class="form-table">
            <tr>
                <th><label for="wr-api">URL interna del motor</label></th>
                <td>
                    <input type="text" id="wr-api" name="webreview_settings[api_base]" value="<?php echo esc_attr($s['api_base']); ?>" class="regular-text">
                    <p class="description">Llamadas servidor→servidor. En Docker: <code>http://engine:3000</code>.</p>
                </td>
            </tr>
            <tr>
                <th><label for="wr-pub">URL pública del motor</label></th>
                <td>
                    <input type="text" id="wr-pub" name="webreview_settings[public_base]" value="<?php echo esc_attr($s['public_base']); ?>" class="regular-text">
                    <p class="description">Para cargar imágenes en el navegador. En local: <code>http://localhost:3000</code>.</p>
                </td>
            </tr>
            <tr>
                <th><label for="wr-token">Token (opcional)</label></th>
                <td>
                    <input type="text" id="wr-token" name="webreview_settings[token]" value="<?php echo esc_attr($s['token']); ?>" class="regular-text">
                    <p class="description">Debe coincidir con <code>WEBREVIEW_TOKEN</code> del motor.</p>
                </td>
            </tr>
        </table>
        <?php submit_button(); ?>
    </form>
</div>
