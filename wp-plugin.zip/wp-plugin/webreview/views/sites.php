<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap webreview">
    <h1>WebReview <span class="wr-ver">v<?php echo esc_html(WEBREVIEW_VERSION); ?></span></h1>

    <?php if (is_wp_error($health)) : ?>
        <div class="notice notice-error"><p>
            ⚠️ No se puede contactar con el motor: <?php echo esc_html($health->get_error_message()); ?>.
            Revisa la URL en <a href="<?php echo esc_url(admin_url('admin.php?page=webreview-settings')); ?>">Ajustes</a>.
        </p></div>
    <?php else : ?>
        <div class="notice notice-success"><p>✅ Motor conectado (<?php echo intval($health['running'] ?? 0); ?> jobs en curso).</p></div>
    <?php endif; ?>

    <h2>Añadir web</h2>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="wr-add-form">
        <?php wp_nonce_field('webreview_add_site'); ?>
        <input type="hidden" name="action" value="webreview_add_site">
        <input type="text" name="site_name" placeholder="Nombre (ej. Tienda cliente X)" required>
        <input type="url" name="site_url" placeholder="https://ejemplo.com" required>
        <button type="submit" class="button button-primary">Añadir</button>
    </form>

    <h2>Mis webs</h2>
    <table class="widefat striped wr-table">
        <thead>
            <tr><th>Web</th><th>URL</th><th>Páginas</th><th>Último análisis</th><th>Estado</th><th>Acciones</th></tr>
        </thead>
        <tbody>
        <?php if (empty($sites)) : ?>
            <tr><td colspan="6">Aún no has añadido ninguna web.</td></tr>
        <?php else : foreach ($sites as $s) : $npages = count($s['pages'] ?? []); ?>
            <tr data-site-id="<?php echo esc_attr($s['id']); ?>" data-site-name="<?php echo esc_attr($s['name']); ?>" data-pages="<?php echo esc_attr(wp_json_encode(array_values($s['pages'] ?? []))); ?>">
                <td><strong><?php echo esc_html($s['name']); ?></strong></td>
                <td><a href="<?php echo esc_url($s['url']); ?>" target="_blank"><?php echo esc_html($s['url']); ?></a></td>
                <td>
                    <?php if ($npages) : ?>
                        <span class="wr-badge wr-badge-ok"><?php echo intval($npages); ?> seleccionadas</span>
                    <?php else : ?>
                        <span class="wr-badge">todo el árbol</span>
                    <?php endif; ?>
                </td>
                <td><?php echo $s['last_run'] ? esc_html($s['last_run']) : '—'; ?></td>
                <td>
                    <?php if ($s['last_alert'] === null) : ?>—
                    <?php elseif ($s['last_alert'] > 0) : ?><span class="wr-badge wr-badge-alert"><?php echo intval($s['last_alert']); ?> cambios</span>
                    <?php else : ?><span class="wr-badge wr-badge-ok">Sin cambios</span><?php endif; ?>
                </td>
                <td class="wr-actions">
                    <button class="button wr-discover">🧭 Descubrir</button>
                    <button class="button wr-baseline">📸 Baseline</button>
                    <button class="button button-primary wr-check">🔍 Comprobar</button>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline">
                        <?php wp_nonce_field('webreview_delete_site'); ?>
                        <input type="hidden" name="action" value="webreview_delete_site">
                        <input type="hidden" name="site_id" value="<?php echo esc_attr($s['id']); ?>">
                        <button type="submit" class="button-link-delete" onclick="return confirm('¿Eliminar esta web?')">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>

    <div id="wr-panel" class="wr-panel" style="display:none">
        <h2 id="wr-panel-title"></h2>
        <div id="wr-panel-status" class="wr-status"></div>
        <pre id="wr-panel-logs" class="wr-logs"></pre>
        <div id="wr-panel-results"></div>
    </div>
</div>
