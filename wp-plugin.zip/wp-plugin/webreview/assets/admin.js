(function () {
  "use strict";

  function post(action, data) {
    const body = new URLSearchParams();
    body.append("action", action);
    body.append("nonce", WebReview.nonce);
    for (const k in data) {
      if (Array.isArray(data[k])) data[k].forEach((v) => body.append(k + "[]", v));
      else body.append(k, data[k]);
    }
    return fetch(WebReview.ajaxUrl, { method: "POST", body })
      .then((r) => r.json());
  }

  const panel = document.getElementById("wr-panel");
  const elTitle = document.getElementById("wr-panel-title");
  const elStatus = document.getElementById("wr-panel-status");
  const elLogs = document.getElementById("wr-panel-logs");
  const elResults = document.getElementById("wr-panel-results");

  let discoverPreselect = []; // URLs ya guardadas de la web en curso

  function esc(s) {
    return String(s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function img(src, label) {
    return `<figure class="wr-fig"><figcaption>${label}</figcaption>` +
      `<a href="${src}" target="_blank"><img src="${src}" loading="lazy"></a></figure>`;
  }

  function renderCheck(result) {
    const site = result.site;
    const runDir = result.runDir;
    const base = WebReview.publicBase + "/data/";
    const s = result.summary;
    let html = `<div class="wr-summary">` +
      `<span>Comparadas: <b>${s.compared}</b></span>` +
      `<span class="${s.alerts ? "wr-alert" : "wr-ok"}">Con cambios: <b>${s.alerts}</b></span>` +
      (s.newPages.length ? `<span>Nuevas: <b>${s.newPages.length}</b></span>` : "") +
      (s.removedPages.length ? `<span>Eliminadas: <b>${s.removedPages.length}</b></span>` : "") +
      `</div>`;

    result.report.pages.forEach((p) => {
      Object.keys(p.shots).forEach((bp) => {
        const shot = p.shots[bp];
        if (shot.status === "missing") return;
        const changed = shot.status === "changed";
        html += `<details class="wr-page ${changed ? "wr-changed" : ""}" ${changed ? "open" : ""}>` +
          `<summary>${changed ? "⚠️" : "✓"} ${p.slug} <em>[${bp}]</em> · ${shot.changeRatio}% cambiado</summary>` +
          `<div class="wr-triptico">` +
            img(base + site + "/baseline/" + shot.baseImg, "Baseline") +
            img(base + runDir + "/" + shot.newImg, "Actual") +
            img(base + runDir + "/" + shot.diff, "Diferencias") +
          `</div></details>`;
      });
    });
    elResults.innerHTML = html;
  }

  function renderBaseline(result) {
    elResults.innerHTML = `<div class="wr-summary">` +
      `✅ Baseline creado: <b>${result.pages}</b> páginas · breakpoints: ${result.breakpoints.join(", ")}</div>`;
  }

  function renderDiscover(result, siteId) {
    const pre = new Set(discoverPreselect);
    const autoPick = pre.size === 0; // sin selección previa → sugerir 1 por plantilla
    let html = `<div class="wr-summary">` +
      `<span>URLs encontradas: <b>${result.total}</b></span>` +
      `<span>Plantillas: <b>${result.groups.length}</b></span></div>` +
      `<p class="description">Elige qué URLs monitorizar. Recomendado: 1–2 por plantilla ` +
      `(así cubres todos los tipos sin capturar miles de páginas).</p>` +
      `<div class="wr-groups">`;

    result.groups.forEach((g) => {
      html += `<details class="wr-group" open><summary>` +
        `<b>${esc(g.label)}</b> · ${g.count} URL${g.count > 1 ? "s" : ""}` +
        `<label class="wr-pick-all"><input type="checkbox" class="wr-group-all"> todas</label>` +
        `</summary><ul class="wr-url-list">`;
      g.urls.forEach((u, ui) => {
        const checked = autoPick ? ui === 0 : pre.has(u);
        html += `<li><label><input type="checkbox" class="wr-url" value="${esc(u)}"` +
          `${checked ? " checked" : ""}> ${esc(u)}</label></li>`;
      });
      html += `</ul></details>`;
    });

    html += `</div><p><button class="button button-primary wr-save-pages" ` +
      `data-site-id="${esc(siteId)}">💾 Guardar selección</button> ` +
      `<span class="wr-save-msg"></span></p>`;
    elResults.innerHTML = html;
  }

  function poll(jobId, siteId) {
    post("webreview_status", { job_id: jobId, site_id: siteId }).then((r) => {
      if (!r.success) {
        elStatus.textContent = "Error: " + (r.data ? r.data.message : "desconocido");
        elStatus.className = "wr-status wr-alert";
        return;
      }
      const job = r.data;
      elStatus.textContent = "Estado: " + job.status;
      elLogs.textContent = (job.logs || []).join("\n");
      elLogs.scrollTop = elLogs.scrollHeight;

      if (job.status === "done") {
        elStatus.className = "wr-status wr-ok";
        if (job.type === "check") renderCheck(job.result);
        else if (job.type === "discover") renderDiscover(job.result, siteId);
        else renderBaseline(job.result);
      } else if (job.status === "error") {
        elStatus.className = "wr-status wr-alert";
        elStatus.textContent = "Error: " + job.error;
      } else {
        setTimeout(() => poll(jobId, siteId), 2000);
      }
    });
  }

  const TITLES = { baseline: "📸 Baseline · ", check: "🔍 Comprobación · ", discover: "🧭 Descubrir · " };

  function start(type, row) {
    const siteId = row.dataset.siteId;
    const name = row.dataset.siteName;
    try { discoverPreselect = JSON.parse(row.dataset.pages || "[]"); } catch (e) { discoverPreselect = []; }
    panel.style.display = "block";
    elTitle.textContent = (TITLES[type] || "") + name;
    elStatus.textContent = "Encolando...";
    elStatus.className = "wr-status";
    elLogs.textContent = "";
    elResults.innerHTML = "";
    panel.scrollIntoView({ behavior: "smooth" });

    post("webreview_start", { type: type, site_id: siteId }).then((r) => {
      if (!r.success) {
        elStatus.textContent = "Error: " + (r.data ? r.data.message : "desconocido");
        elStatus.className = "wr-status wr-alert";
        return;
      }
      poll(r.data.jobId, siteId);
    });
  }

  document.addEventListener("click", (e) => {
    const row = e.target.closest("tr[data-site-id]");
    if (row) {
      if (e.target.classList.contains("wr-discover")) { e.preventDefault(); start("discover", row); }
      if (e.target.classList.contains("wr-baseline")) { e.preventDefault(); start("baseline", row); }
      if (e.target.classList.contains("wr-check")) { e.preventDefault(); start("check", row); }
    }
    if (e.target.classList.contains("wr-save-pages")) { e.preventDefault(); savePages(e.target); }
  });

  // Checkbox "todas" de un grupo → marca/desmarca sus URLs.
  elResults.addEventListener("change", (e) => {
    if (!e.target.classList.contains("wr-group-all")) return;
    const details = e.target.closest(".wr-group");
    details.querySelectorAll(".wr-url").forEach((cb) => { cb.checked = e.target.checked; });
  });

  function savePages(btn) {
    const siteId = btn.dataset.siteId;
    const urls = Array.from(elResults.querySelectorAll(".wr-url:checked")).map((cb) => cb.value);
    const msg = elResults.querySelector(".wr-save-msg");
    btn.disabled = true;
    if (msg) msg.textContent = "Guardando...";
    post("webreview_save_pages", { site_id: siteId, pages: urls }).then((r) => {
      btn.disabled = false;
      if (!r.success) { if (msg) msg.textContent = "Error: " + (r.data ? r.data.message : "?"); return; }
      if (msg) msg.textContent = "✅ " + r.data.count + " URLs guardadas.";
      // Refleja el cambio en la fila sin recargar.
      const row = document.querySelector(`tr[data-site-id="${siteId}"]`);
      if (row) {
        row.dataset.pages = JSON.stringify(urls);
        const badge = row.querySelector("td:nth-child(3) .wr-badge");
        if (badge) {
          badge.textContent = urls.length ? urls.length + " seleccionadas" : "todo el árbol";
          badge.className = "wr-badge" + (urls.length ? " wr-badge-ok" : "");
        }
      }
    });
  }
})();
