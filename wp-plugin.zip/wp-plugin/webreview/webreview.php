<?php
/**
 * Plugin Name: WebReview
 * Description: Monitoriza cambios visuales de tus webs. Crea un baseline antes de actualizar y compara después. Orquesta un motor Playwright externo.
 * Version: 0.2.0
 * Author: ablancodev
 */

if (!defined('ABSPATH')) exit;

define('WEBREVIEW_VERSION', '0.2.0');
define('WEBREVIEW_DIR', plugin_dir_path(__FILE__));
define('WEBREVIEW_URL', plugin_dir_url(__FILE__));

require_once WEBREVIEW_DIR . 'includes/class-webreview-client.php';
require_once WEBREVIEW_DIR . 'includes/class-webreview-sites.php';
require_once WEBREVIEW_DIR . 'includes/class-webreview-admin.php';
require_once WEBREVIEW_DIR . 'includes/class-webreview-ajax.php';

add_action('plugins_loaded', function () {
    new WebReview_Admin();
    new WebReview_Ajax();
});

// Ajustes por defecto al activar.
register_activation_hook(__FILE__, function () {
    if (get_option('webreview_settings') === false) {
        add_option('webreview_settings', [
            // URL interna para llamadas servidor→servidor (red Docker).
            'api_base'    => 'http://engine:3000',
            // URL pública para que el navegador cargue las imágenes.
            'public_base' => 'http://localhost:3000',
            'token'       => '',
        ]);
    }
    if (get_option('webreview_sites') === false) {
        add_option('webreview_sites', []);
    }
});
