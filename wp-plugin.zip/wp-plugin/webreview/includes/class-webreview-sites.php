<?php
if (!defined('ABSPATH')) exit;

/**
 * Gestión de las webs monitorizadas (almacenadas en una option).
 * En un SaaS real esto sería una tabla propia por usuario/tenant.
 */
class WebReview_Sites {

    const OPTION = 'webreview_sites';

    public static function all() {
        $sites = get_option(self::OPTION, []);
        return is_array($sites) ? $sites : [];
    }

    public static function get($id) {
        foreach (self::all() as $s) {
            if ($s['id'] === $id) return $s;
        }
        return null;
    }

    public static function add($name, $url) {
        $sites = self::all();
        $site = [
            'id'         => wp_generate_uuid4(),
            'name'       => sanitize_text_field($name),
            'url'        => esc_url_raw($url),
            'created'    => current_time('mysql'),
            'last_run'   => null,
            'last_alert' => null,
            'pages'      => [], // URLs curadas a monitorizar (vacío = rastrear todo)
        ];
        $sites[] = $site;
        update_option(self::OPTION, $sites);
        return $site;
    }

    /** Guarda la lista curada de URLs de una web. */
    public static function set_pages($id, $urls) {
        $clean = array_values(array_unique(array_filter(array_map('esc_url_raw', (array) $urls))));
        self::update($id, ['pages' => $clean]);
        return $clean;
    }

    public static function update($id, $fields) {
        $sites = self::all();
        foreach ($sites as &$s) {
            if ($s['id'] === $id) {
                $s = array_merge($s, $fields);
                break;
            }
        }
        update_option(self::OPTION, $sites);
    }

    public static function delete($id) {
        $sites = array_values(array_filter(self::all(), fn($s) => $s['id'] !== $id));
        update_option(self::OPTION, $sites);
    }
}
