<?php
if (!defined('ABSPATH')) exit;

/**
 * Cliente HTTP hacia el motor Playwright.
 */
class WebReview_Client {

    public static function settings() {
        return wp_parse_args(get_option('webreview_settings', []), [
            'api_base'    => 'http://engine:3000',
            'public_base' => 'http://localhost:3000',
            'token'       => '',
        ]);
    }

    protected static function headers() {
        $s = self::settings();
        $h = ['Content-Type' => 'application/json'];
        if (!empty($s['token'])) {
            $h['Authorization'] = 'Bearer ' . $s['token'];
        }
        return $h;
    }

    /** Lanza un job (baseline|check). Devuelve array con id o WP_Error. */
    public static function start_job($type, $url, $options = []) {
        $s = self::settings();
        $res = wp_remote_post(trailingslashit($s['api_base']) . 'jobs', [
            'headers' => self::headers(),
            'timeout' => 15,
            'body'    => wp_json_encode([
                'type'    => $type,
                'url'     => $url,
                'options' => $options,
            ]),
        ]);
        return self::parse($res);
    }

    /** Consulta el estado de un job. */
    public static function job_status($id) {
        $s = self::settings();
        $res = wp_remote_get(trailingslashit($s['api_base']) . 'jobs/' . rawurlencode($id), [
            'headers' => self::headers(),
            'timeout' => 15,
        ]);
        return self::parse($res);
    }

    /** Comprueba que el motor responde. */
    public static function health() {
        $s = self::settings();
        $res = wp_remote_get(trailingslashit($s['api_base']) . 'health', ['timeout' => 8]);
        return self::parse($res);
    }

    protected static function parse($res) {
        if (is_wp_error($res)) return $res;
        $code = wp_remote_retrieve_response_code($res);
        $body = json_decode(wp_remote_retrieve_body($res), true);
        if ($code >= 400) {
            return new WP_Error('webreview_api', 'Motor respondió ' . $code . ': ' . ($body['error'] ?? 'error'));
        }
        return $body;
    }
}
