<?php
if (!defined('ABSPATH')) exit;

class WebReview_Admin {

    public function __construct() {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_post_webreview_add_site', [$this, 'handle_add_site']);
        add_action('admin_post_webreview_delete_site', [$this, 'handle_delete_site']);
    }

    public function menu() {
        add_menu_page('WebReview', 'WebReview', 'manage_options', 'webreview',
            [$this, 'page_sites'], 'dashicons-camera-alt', 58);
        add_submenu_page('webreview', 'Webs', 'Webs', 'manage_options', 'webreview',
            [$this, 'page_sites']);
        add_submenu_page('webreview', 'Ajustes', 'Ajustes', 'manage_options', 'webreview-settings',
            [$this, 'page_settings']);
    }

    public function assets($hook) {
        if (strpos($hook, 'webreview') === false) return;
        wp_enqueue_style('webreview-admin', WEBREVIEW_URL . 'assets/admin.css', [], WEBREVIEW_VERSION);
        wp_enqueue_script('webreview-admin', WEBREVIEW_URL . 'assets/admin.js', [], WEBREVIEW_VERSION, true);
        $s = WebReview_Client::settings();
        wp_localize_script('webreview-admin', 'WebReview', [
            'ajaxUrl'    => admin_url('admin-ajax.php'),
            'nonce'      => wp_create_nonce('webreview'),
            'publicBase' => untrailingslashit($s['public_base']),
        ]);
    }

    public function register_settings() {
        register_setting('webreview_settings_group', 'webreview_settings', [
            'sanitize_callback' => function ($v) {
                return [
                    'api_base'    => esc_url_raw($v['api_base'] ?? ''),
                    'public_base' => esc_url_raw($v['public_base'] ?? ''),
                    'token'       => sanitize_text_field($v['token'] ?? ''),
                ];
            },
        ]);
    }

    public function handle_add_site() {
        check_admin_referer('webreview_add_site');
        if (!current_user_can('manage_options')) wp_die('nope');
        $name = $_POST['site_name'] ?? '';
        $url  = $_POST['site_url'] ?? '';
        if ($name && $url) WebReview_Sites::add($name, $url);
        wp_safe_redirect(admin_url('admin.php?page=webreview'));
        exit;
    }

    public function handle_delete_site() {
        check_admin_referer('webreview_delete_site');
        if (!current_user_can('manage_options')) wp_die('nope');
        WebReview_Sites::delete($_POST['site_id'] ?? '');
        wp_safe_redirect(admin_url('admin.php?page=webreview'));
        exit;
    }

    public function page_sites() {
        $sites  = WebReview_Sites::all();
        $health = WebReview_Client::health();
        include WEBREVIEW_DIR . 'views/sites.php';
    }

    public function page_settings() {
        include WEBREVIEW_DIR . 'views/settings.php';
    }
}
