<?php
if (!defined('ABSPATH')) exit;

/**
 * Puentes AJAX entre el admin y el motor.
 */
class WebReview_Ajax {

    public function __construct() {
        add_action('wp_ajax_webreview_start', [$this, 'start']);
        add_action('wp_ajax_webreview_status', [$this, 'status']);
        add_action('wp_ajax_webreview_save_pages', [$this, 'save_pages']);
    }

    protected function guard() {
        check_ajax_referer('webreview', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Sin permisos'], 403);
        }
    }

    /** Lanza un baseline o check para una web. */
    public function start() {
        $this->guard();
        $type    = $_POST['type'] ?? '';
        $site_id = $_POST['site_id'] ?? '';
        $site    = WebReview_Sites::get($site_id);

        if (!$site || !in_array($type, ['baseline', 'check', 'discover'], true)) {
            wp_send_json_error(['message' => 'Parámetros inválidos']);
        }

        $options = [];
        if (!empty($_POST['max']))         $options['maxPages']    = intval($_POST['max']);
        if (!empty($_POST['breakpoints'])) $options['breakpoints'] = array_map('sanitize_text_field', (array) $_POST['breakpoints']);

        // Baseline y check usan la lista curada de la web si existe.
        if (in_array($type, ['baseline', 'check'], true) && !empty($site['pages'])) {
            $options['urls'] = array_values($site['pages']);
        }

        $res = WebReview_Client::start_job($type, $site['url'], $options);
        if (is_wp_error($res)) {
            wp_send_json_error(['message' => $res->get_error_message()]);
        }
        wp_send_json_success(['jobId' => $res['id'], 'siteId' => $site_id, 'type' => $type]);
    }

    /** Consulta el estado del job y, si terminó, actualiza la web. */
    public function status() {
        $this->guard();
        $job_id  = sanitize_text_field($_POST['job_id'] ?? '');
        $site_id = sanitize_text_field($_POST['site_id'] ?? '');
        $res = WebReview_Client::job_status($job_id);
        if (is_wp_error($res)) {
            wp_send_json_error(['message' => $res->get_error_message()]);
        }

        if ($res['status'] === 'done' && $site_id && $res['type'] === 'check') {
            $alerts = $res['result']['summary']['alerts'] ?? 0;
            WebReview_Sites::update($site_id, [
                'last_run'   => current_time('mysql'),
                'last_alert' => $alerts,
            ]);
        } elseif ($res['status'] === 'done' && $site_id && $res['type'] === 'baseline') {
            WebReview_Sites::update($site_id, ['last_run' => current_time('mysql')]);
        }

        wp_send_json_success($res);
    }

    /** Guarda las URLs seleccionadas por el usuario para una web. */
    public function save_pages() {
        $this->guard();
        $site_id = sanitize_text_field($_POST['site_id'] ?? '');
        $site    = WebReview_Sites::get($site_id);
        if (!$site) {
            wp_send_json_error(['message' => 'Web no encontrada']);
        }
        $urls  = isset($_POST['pages']) ? (array) wp_unslash($_POST['pages']) : [];
        $clean = WebReview_Sites::set_pages($site_id, $urls);
        wp_send_json_success(['count' => count($clean)]);
    }
}
